import React from 'react';
import Contact from './components/contact';
import './App.css';

const App = () => {
  return (
    <div className="container">
      <header>
        <h1>Coming Soon</h1>
        <p>Our bed and pillow covers store is launching soon!</p>
      </header>
      
      <main>
        <Contact />
      </main>
    </div>
  );
};

export default App;